# python_for_the_financial_economist
Repository for code, notebooks, data, etc. for the course "Python for the financial economist" at CBS
